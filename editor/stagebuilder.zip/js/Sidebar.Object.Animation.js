import {
  UIBreak,
  UIButton,
  UIDiv,
  UIText,
  UINumber,
  UIRow,
} from "./libs/ui.js";

function SidebarObjectAnimation(editor) {
  const strings = editor.strings;
  const signals = editor.signals;
  const mixer = editor.mixer;

  function getButtonText(action) {
    return action.isRunning()
      ? strings.getKey("sidebar/animations/stop")
      : strings.getKey("sidebar/animations/play");
  }

  function Animation(animation, object) {
    console.log("sidebar.object.animation.js------animation");
    console.log(mixer);
    console.log(strings);
    console.log(signals);
    const action = mixer.clipAction(animation, object);
    console.log(action);
    const container = new UIRow();

    const name = new UIText(animation.name).setWidth("200px");
    container.add(name);

    const button = new UIButton(getButtonText(action));
    button.onClick(function () {
      console.log(action.isRunning());
      action.isRunning() ? action.stop() : action.play();
      button.setTextContent(getButtonText(action));
    });

    container.add(button);

    return container;
  }

  signals.objectSelected.add(function (object) {
    if (object !== null && object.animations.length > 0) {
      animationsList.clear();
      console.log("object");

      const animations = object.animations;

      for (const animation of animations) {
        console.log(animation);
        console.log(object);
        animationsList.add(new Animation(animation, object));
      }

      container.setDisplay("");
    } else {
      container.setDisplay("none");
    }
  });

  signals.objectRemoved.add(function (object) {
    if (object !== null && object.animations.length > 0) {
      mixer.uncacheRoot(object);
    }
  });

  const container = new UIDiv();
  container.setMarginTop("20px");
  container.setDisplay("none");

  container.add(
    new UIText(strings.getKey("sidebar/animations")).setTextTransform(
      "uppercase",
    ),
  );
  container.add(new UIBreak());
  container.add(new UIBreak());

  const animationsList = new UIDiv();
  container.add(animationsList);

  const mixerTimeScaleRow = new UIRow();
  const mixerTimeScaleNumber = new UINumber(1)
    .setWidth("60px")
    .setRange(-10, 10);
  mixerTimeScaleNumber.onChange(function () {
    mixer.timeScale = mixerTimeScaleNumber.getValue();
  });

  mixerTimeScaleRow.add(
    new UIText(strings.getKey("sidebar/animations/timescale")).setClass(
      "Label",
    ),
  );
  mixerTimeScaleRow.add(mixerTimeScaleNumber);

  container.add(mixerTimeScaleRow);

  return container;
}

export { SidebarObjectAnimation };
